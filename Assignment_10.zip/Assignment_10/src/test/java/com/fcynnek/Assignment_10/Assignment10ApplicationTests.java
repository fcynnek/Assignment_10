package com.fcynnek.Assignment_10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
